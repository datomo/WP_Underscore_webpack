
//Require SASS
require('../sass/main.sass')

// //Require CSS
// require('../style.css')

//Require scripts
require('./script')

//require vendor
require('./vendor/TweenLite.min.js')
require('script-loader!./vendor/ScrollToPlugin.min.js')


//require menu
require('./menu')

//require img
require('./img')
