require('../img/Date_01.svg')
require('../img/banner.svg')
